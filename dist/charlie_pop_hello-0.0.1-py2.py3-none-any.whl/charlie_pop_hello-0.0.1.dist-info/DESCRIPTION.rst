Hello.py
=========

A script which will greet the user.


Installation
--------------

Install with pip


Usage
------

Simply pass a name to hello.py and the program will print out 'Hello, {name}'




Release History
===============

0.0.1
------

* Initial release for hello_world
* 100% test coverage
* Minimal documentation  


