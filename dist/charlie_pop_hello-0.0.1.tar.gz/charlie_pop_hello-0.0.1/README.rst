Hello.py
=========

A script which will greet the user.


Installation
--------------

Install with pip


Usage
------

Simply pass a name to hello.py and the program will print out 'Hello, {name}'


